import { Component } from '@angular/core';
import { DownloadService } from './download.service'
import { Download } from './download'
import { Observable } from 'rxjs'
import { tap } from 'rxjs/operators'

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {

  slides = 
    {name: 'Let\'s talk about Node.js.pdf', url: 'https://nils-mehlhorn.de/slides/nodejs_mehlhorn_ijs.pdf'}

  download$: Observable<Download<Blob>>


  constructor(private downloads: DownloadService) {}

  download({name, url}: {name: string, url: string}) {
    this.download$ = this.downloads.download(url, name)
  }
}
