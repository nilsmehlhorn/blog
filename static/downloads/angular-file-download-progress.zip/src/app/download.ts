import {HttpEvent, HttpSentEvent, HttpEventType,  HttpHeaderResponse, HttpResponse, HttpProgressEvent} from '@angular/common/http'
import { Observable, throwError } from 'rxjs'
import { catchError, tap, map } from 'rxjs/operators'
import { saveAs } from 'file-saver';

function isHttpResponse<T>(event: HttpEvent<T>): event is HttpResponse<T> {
  return event.type === HttpEventType.Response
}

function isHttpProgressEvent(event: HttpEvent<unknown>): event is HttpProgressEvent {
  return event.type === HttpEventType.DownloadProgress || event.type === HttpEventType.UploadProgress
}

export interface Download<T> {
  content?: T
  progress: number
  state: 'PENDING' | 'IN_PROGRESS' | 'DONE'
}

export function toDownload<T>(event: HttpEvent<T>): Download<T> {
  if (isHttpProgressEvent(event)) {
    return {
      progress: Math.round(100 * event.loaded / event.total),
      state: 'IN_PROGRESS'
    }
  }
  if (isHttpResponse(event)) {
    return {
      progress: 100,
      state: 'DONE',
      content: event.body
    }
  }
  return {progress: 0, state: 'PENDING'}
}

export function download(filename?: string): (source: Observable<HttpEvent<Blob>>) => Observable<Download<Blob>> {
  let saved = false;
  return (source: Observable<HttpEvent<Blob>>) => source.pipe(
    map(toDownload),
    tap(download => {
      if (download.state === 'DONE' && !saved) {
        saveAs(download.content, filename)
        saved = true
      }
    })
  )
}