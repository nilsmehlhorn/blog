import { Injectable } from '@angular/core'
import { HttpClient, HttpRequest } from '@angular/common/http'
import { download, Download } from './download'
import { map } from 'rxjs/operators'
import { Observable } from 'rxjs'

@Injectable({providedIn: 'root'})
export class DownloadService {

  constructor(private http: HttpClient) {
  }

  download(url: string, filename?: string): Observable<Download<Blob>> {
    return this.http.get('https://nils-mehlhorn.de/slides/nodejs_mehlhorn_ijs.pdf', {
      reportProgress: true,
      observe: 'events',
      responseType: 'blob'
    }).pipe(download(filename))
  }
}